---
title: "Java����(��ʮ��)ʵ�־����ȵ����-ת��-����ʽ-��������"
list_number: false
date: 2017-01-04 18:32
categories: Java
tags: [java, ����, �����]
description: "# Java����(��ʮ��)ʵ�־���ת��-����ʽ-�������� #"
---
# Java����(��ʮ��)ʵ�־���ת��-����ʽ-�������� #

??Ӧ����������Ҫ�������������  
??��Ӧ�ľ���������������£�

    package cn.edu.ujn.paper.matrix;
    
    public class MatrixUtil {
    
        /** * ʵ�־������ (AB) * @param a ����A * @param b ����B */
        private static double[][] matrixMulti(double[][] a,double[][] b){
    
            double c[][] = new double[a.length][b[0].length];
    
            int x,i,j;
            for(i = 0;i<a.length ;i++)
            {  
                for(j = 0;j<b[0].length;j++)
                {  
                    int temp = 0;
                    for(x = 0;x<b.length;x++)
                    {  
                        temp+=a[i][x]*b[x][j];
    
                    }  
                    c[i][j] = temp;
    
                }  
            }  
            System.out.println("������˺���Ϊ��");  
            for(int m = 0; m < a.length; m++)  
            {  
                for(int n = 0; n < b[0].length; n++)  
                {  
                    System.out.print(c[m][n]+"\t");
                }  
                System.out.println();  
            }
    
            MatrixUtil.getHL(c);
    
            return c;  
        }
    
        /** * �����ӡ * @param matrix ���� * @param r �� * @param c �� */
        public static void printMatrix(double[][] matrix, int r, int c){
            System.out.println("��ӡ����");
            String Strr = new String("");
            for (int i = 0; i < r; i++) {
                for (int j = 0; j < c; j++) {
                    String str = String.valueOf(matrix[i][j]);
                    Strr += str;
                    Strr += "\t";
                }
                Strr += "\n";
            }
    
            System.out.println(Strr);
        }
    
        /** * ����������ʽ * @param data ԭʼ���� * @param h �����Ԫ�ص��� * @param v �����Ԫ�ص��� * @return */
        public static double[][] getDY(double[][] data, int h, int v) {  
            int H = data.length;  
            int V = data[0].length;  
    
            double[][] newData = new double[H - 1][V - 1];  
    
            for (int i = 0; i < newData.length; i++) {
    
                if (i < h - 1) {  
                    for (int j = 0; j < newData[i].length; j++) {
                        if (j < v - 1) {
                            newData[i][j] = data[i][j];
                        } else {
                            newData[i][j] = data[i][j + 1];
                        }
                    }
                } else {
                    for (int j = 0; j < newData[i].length; j++) {
                        if (j < v - 1) {
                            newData[i][j] = data[i + 1][j];
                        } else {
                            newData[i][j] = data[i + 1][j + 1];
                        }
                    }
    
                }
            }
    
    // System.out.println("---------------------��������ʽ����---------------------------------");
    
    /* for(int i = 0; i < newData.length; i++){ for(int j = 0; j < newData[i].length; j++){ System.out.print("newData[" + i + "]" + "[" + j + "]=" + newData[i][j] + " "); } System.out.println(); }*/
    
            return newData;  
        }   
    
        /** * �������ʽ��ģ * * @param data * @return float */  
        public static double getHL(double[][] data) {  
    
            // ��ֹ���� 
            if (data.length == 2) {
                return data[0][0] * data[1][1] - data[0][1] * data[1][0];
            }
    
            if (data.length == 1) {
                return data[0][0];
            }
    
            double total = 0;
            // ����data �õ�����ʽ������������
            int num = data.length;
            // ����һ����СΪnum �������Ŷ�Ӧ��չ������Ԫ����ĵ�ֵ
            double[] nums = new double[num];
    
            for (int i = 0; i < num; i++) {
                if (i % 2 == 0) {
                    nums[i] = data[0][i] * getHL(getDY(data, 1, i + 1));
                } else {
                    nums[i] = -data[0][i] * getHL(getDY(data, 1, i + 1));
                }
            }
    
            for (int i = 0; i < num; i++) {  
                total += nums[i];  
            }
    
    // System.out.println("total=" + total);
            return total;  
        }  
    
        /** * ȡ��ת�þ��� * @param A * @return float[][] */  
        public static double[][] getA_T(double[][] A) {  
            int h = A.length;  
            int v = A[0].length;  
            // ������A�к����෴��ת�þ��� 
            double[][] A_T = new double[v][h];  
            // ����Aȡ��ת�þ���A_T 
            for (int i = 0; i < h; i++) {  
                for (int j = 0; j < v; j++) {  
                    A_T[j][i] = A[i][j];  
                }  
            }  
    // System.out.println("ȡ��ת�þ��� wanbi........");
            return A_T;  
        }  
    
        /** * �������� * * @param data * @return */  
        public static double[][] getReverseMatrix(double[][] data) {
    
            // 1.�������ʽ��ģ|data| 
            double m = getHL(data);  
    
            // ������ʽ��ֵΪ0�����������󲻴���
            if(Arith.compareTo(m, 0) == 0){
                System.out.println("----------------����ʽ��ģΪ0������󲻴���-----------------");
                return null;
            }
    
            if(m == 0){
    
            }
    
            System.out.println("����ʽ:" + m);
    
            // ����һ��������������� 
            double[][] newData = new double[data.length][data.length];
    
            for (int i = 0; i < data.length; i++) {
                for (int j = 0; j < data.length; j++) {
                    double num;
                    if ((i + j) % 2 == 0) {
                        num = getHL(getDY(data, i + 1, j + 1));
                    } else {
                        num = -getHL(getDY(data, i + 1, j + 1));
                    }
    
                    newData[i][j] = num / m;
                }
            }
    
            // 2.ת�ô�������ʽ
            newData = getA_T(newData);
    
            // ��ӡ
            System.out.println("�����");
            for (int i = 0; i < data.length; i++) {
                for (int j = 0; j < data.length; j++) {
                    System.out.print("newData[" + i + "][" + j + "]= " + newData[i][j] + " ");
                }
    
                System.out.println();
            }
    
            return newData;
        }  
    
        /** * ���������� * @param Matrix ���� * @param error_ * @param List * @return */
        public static int Rank(double[][] Matrix, int error_, int List)  
        {  
            int n = List;  
            int m = Matrix.length ;  
            int i = 0;  
            int j = 0;  
            int i1, j1;  
            double temp1;
    
            if(m > n)  
            {  
                i = m;
                m = n;
                n = i;
                i = 1;
            }
    
            m -= 1;  
            n -= 1;
    
            double[][]temp = new double[m+1][n+1];
    
            if(i == 0)  
            {
              for(i = 0; i <= m; i++)  
              {
                  for(j = 0; j <= n; j++)  
                  {  
                      temp[i][j] = Matrix[i][j];  
                  }
              }
            } else  
            {  
                for(i = 0; i <= m; i++)  
                {  
                    for(j = 0; j <= n; j++)  
                    {  
                        temp[i][j] = Matrix[j][i];  
                    }
                }  
            }  
    
            if(m == 0)  
            {  
                i = 0;  
                while(i <= n)  
                {  
                    if(Matrix[0][i] != 0)  
                    {  
                        return 1;  
                    }  
                    i += 1;  
                }  
                return 0;
            }
    
            double error0;
            if(error_ == -1)  
            {  
                error0 = Math.pow(0.1, 10);
            }  
            else  
            {  
                error0 = Math.pow(0.1, error_);  
            }  
    
            i = 0;
    
            while(i <= m)
            {
                j = 0;
                while(j <= n)
                {
                    if(temp[i][j] != 0)
                    {
                        error0 *= temp[i][j];
                        i = m;
                        break;
                    }
                    j += 1;
                }
                i += 1;
            }
    
            double error1;
            for(i = 0; i <= m; i++)
            {  
                j = 0;  
                while(j <= n)  
                {  
                    if(temp[i][j] != 0)  
                    {  
                        break;  
                    }  
                    j += 1;
                }
    
                if(j <= n)
                {
                    i1 = 0;  
                    while(i1 <= m)  
                    {  
                        if(temp[i1][j] != 0 && i1 != i)
                        {
                            temp1 = temp[i][j]/temp[i1][j];
                            error1 = Math.abs((temp[i][j] - temp[i1][j]*temp1))*100;
                            error1 += error0;
                            for(j1 = 0; j1 <= n; j1++)
                            {  
                                temp[i1][j1] = temp[i][j1] - temp[i1][j1]*temp1;  
                                if(Math.abs(temp[i1][j1]) < error1)  
                                {  
                                    temp[i1][j1] = 0;
                                }  
                            }  
                        }
                        i1 += 1;
                    }
                }
            }
    
            i1 = 0;
            for(i = 0; i <= m; i++)
            {
                for(j = 0; j <= n; j++)  
                {  
                    if(temp[i][j] != 0)
                    {  
                        i1 += 1;
                        break;
                    }
                }
            }
            return i1;
        }
    
    }

![����дͼƬ����][SouthEast]  
![����дͼƬ����][SouthEast 1]


[SouthEast]: http://img.blog.csdn.net/20161220210636705?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvc3VuaHVhcWlhbmcx/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast
[SouthEast 1]: http://img.blog.csdn.net/20161220210733446?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvc3VuaHVhcWlhbmcx/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast


������Ǩ����[http://blog.csdn.net/sunhuaqiang1/article/details/54022561](http://blog.csdn.net/sunhuaqiang1/article/details/54022561)